// swift-tools-version: 5.9
import PackageDescription
import AppleProductTypes

let package = Package(
    name: "ABandOn",
    platforms: [.iOS("16.0")],
    products: [
        .iOSApplication(
            name: "ABandOn",
            targets: ["AppModule"],
            bundleIdentifier: "com.abandon.ipad",
            teamIdentifier: "",
            displayVersion: "0.1",
            bundleVersion: "1",
            appIcon: .asset("AppIcon"),
            accentColor: .presetColor(.orange),
            supportedDeviceFamilies: [.pad, .phone],
            supportedInterfaceOrientations: [
                .portrait, .landscapeRight, .landscapeLeft,
                .portraitUpsideDown(.when(deviceFamilies: [.pad]))
            ],
            capabilities: [
                .outgoingNetworkConnections(),
                .microphone(purposeString: "录制吉他演奏")
            ]
        )
    ],
    targets: [
        .executableTarget(name: "AppModule", path: ".", resources: [.process("web")])
    ]
)
