#!/bin/bash
# 一键编译：只需要 macOS 自带的 Swift 编译器（Xcode 命令行工具），无需任何第三方依赖
set -e
cd "$(dirname "$0")"
if ! command -v swiftc >/dev/null; then echo "需要命令行工具，正在弹出安装窗口，装完后重新运行本脚本"; xcode-select --install; exit 1; fi
APP=ABandOn.app
rm -rf "$APP"; mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
swiftc -O Sources/*.swift -o "$APP/Contents/MacOS/ABandOn"
cp -R web "$APP/Contents/Resources/web"
cp Resources/AppIcon.icns "$APP/Contents/Resources/AppIcon.icns"
cat > "$APP/Contents/Info.plist" <<PL
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleExecutable</key><string>ABandOn</string>
<key>CFBundleIdentifier</key><string>com.abandon.app</string>
<key>NSMicrophoneUsageDescription</key><string>ABandOn 需要使用音频输入来录制你的吉他演奏</string>
<key>CFBundleName</key><string>ABandOn</string>
<key>CFBundleIconFile</key><string>AppIcon</string>
<key>CFBundleDocumentTypes</key><array><dict><key>CFBundleTypeName</key><string>Guitar Pro</string><key>CFBundleTypeRole</key><string>Editor</string><key>LSHandlerRank</key><string>Alternate</string><key>CFBundleTypeExtensions</key><array><string>gp</string><string>gpx</string><string>gp5</string><string>gp4</string><string>gp3</string><string>musicxml</string><string>xml</string><string>mxl</string><string>mscz</string><string>mscx</string></array></dict></array>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleShortVersionString</key><string>0.1</string>
<key>LSMinimumSystemVersion</key><string>12.0</string>
<key>NSHighResolutionCapable</key><true/>
</dict></plist>
PL
codesign --force --deep -s - "$APP" 2>/dev/null || true
xattr -cr "$APP" 2>/dev/null || true
echo "完成：$(pwd)/$APP"
open "$APP"
