import Cocoa
import WebKit

final class AppDelegate: NSObject, NSApplicationDelegate, WKScriptMessageHandler, WKUIDelegate, WKNavigationDelegate {
    var loaded = false
    var pending: String?
    var window: NSWindow!
    var web: WKWebView!
    var files: LocalFiles!

    func applicationDidFinishLaunching(_ n: Notification) {
        files = LocalFiles(root: Bundle.main.resourceURL!.appendingPathComponent("web"))
        let cfg = WKWebViewConfiguration()
        cfg.setURLSchemeHandler(files, forURLScheme: "abandon")
        cfg.userContentController.add(self, name: "host")
        // 告诉网页：这是 macOS 原生外壳（打开/保存/导出/撤销/重做/主页 等由系统菜单栏承担）
        let us = WKUserScript(source: "document.documentElement.classList.add('mac')", injectionTime: .atDocumentStart, forMainFrameOnly: true)
        cfg.userContentController.addUserScript(us)
        cfg.mediaTypesRequiringUserActionForPlayback = []
        web = WKWebView(frame: .zero, configuration: cfg)
        web.uiDelegate = self
        Recorder.shared.onLevel = { [weak self] p in self?.web.evaluateJavaScript("window.recLevel&&recLevel(\(p))") }
        web.navigationDelegate = self
        web.setValue(false, forKey: "drawsBackground")
        web.load(URLRequest(url: URL(string: "abandon://local/index.html")!))

        window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 1280, height: 860),
                          styleMask: [.titled, .closable, .miniaturizable, .resizable],
                          backing: .buffered, defer: false)
        window.title = "ABandOn"
        window.contentView = web
        window.center()
        window.makeKeyAndOrderFront(nil)

        let menu = NSMenu()
        let appItem = NSMenuItem()
        menu.addItem(appItem)
        let appMenu = NSMenu()
        appItem.submenu = appMenu
        appMenu.addItem(withTitle: "退出 ABandOn", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")

        let homeMenu = addTop(menu, "主页")
        item(homeMenu, "资料库", "home-t", "h", [.command, .shift])

        let editMenu = addTop(menu, "编辑")
        item(editMenu, "打开…", "open", "o", [.command])
        item(editMenu, "保存", "save", "s", [.command])
        item(editMenu, "导出…", "export", "e", [.command, .shift])
        editMenu.addItem(NSMenuItem.separator())
        item(editMenu, "撤销", "undo", "z", [.command])
        item(editMenu, "乐谱信息…", "info", "i", [.command])
        editMenu.addItem(NSMenuItem.separator())
        editMenu.addItem(withTitle: "剪切", action: #selector(NSText.cut(_:)), keyEquivalent: "x")
        editMenu.addItem(withTitle: "拷贝", action: #selector(NSText.copy(_:)), keyEquivalent: "c")
        editMenu.addItem(withTitle: "粘贴", action: #selector(NSText.paste(_:)), keyEquivalent: "v")
        editMenu.addItem(withTitle: "全选", action: #selector(NSText.selectAll(_:)), keyEquivalent: "a")

        let createMenu = addTop(menu, "创作")
        item(createMenu, "钢琴伴奏…", "pgen", "", [])
        item(createMenu, "钢琴 Solo…", "psolo", "", [])
        item(createMenu, "合并乐谱…", "pmerge", "", [])
        createMenu.addItem(NSMenuItem.separator())
        item(createMenu, "录音…", "rec-t", "", [])
        item(createMenu, "移调…", "xpose", "", [])
        createMenu.addItem(NSMenuItem.separator())
        item(createMenu, "重做", "redo", "z", [.command, .shift])
        NSApp.mainMenu = menu
        NSApp.activate(ignoringOtherApps: true)
    }


    // 顶部菜单栏：每个菜单项把对应的 id 交给网页里的 menuCmd
    func addTop(_ menu: NSMenu, _ title: String) -> NSMenu {
        let top = NSMenuItem()
        menu.addItem(top)
        let sub = NSMenu(title: title)
        top.submenu = sub
        return sub
    }
    func item(_ sub: NSMenu, _ title: String, _ id: String, _ key: String, _ mods: NSEvent.ModifierFlags) {
        let mi = NSMenuItem(title: title, action: #selector(fire(_:)), keyEquivalent: key)
        mi.keyEquivalentModifierMask = mods
        mi.representedObject = id
        mi.target = self
        sub.addItem(mi)
    }
    @objc func fire(_ s: NSMenuItem) {
        guard let id = s.representedObject as? String else { return }
        web.evaluateJavaScript("window.menuCmd&&menuCmd('\(id)')")
    }

    // 在 Finder 中双击 / 拖到 Dock 图标打开谱子
    func application(_ sender: NSApplication, openFile filename: String) -> Bool {
        if loaded { send(URL(fileURLWithPath: filename)) } else { pending = filename }
        return true
    }
    func webView(_ w: WKWebView, didFinish n: WKNavigation!) {
        loaded = true
        if let p = pending { send(URL(fileURLWithPath: p)); pending = nil }
    }
    func send(_ u: URL) {
        guard let d = try? Data(contentsOf: u) else { return }
        let name = u.lastPathComponent.replacingOccurrences(of: "\\", with: "\\\\").replacingOccurrences(of: "'", with: "\\'")
        web.evaluateJavaScript("onOpen('\(name)','\(d.base64EncodedString())')")
        window.title = "ABandOn — " + u.lastPathComponent
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ app: NSApplication) -> Bool { true }

    // JS -> Swift：打开 / 保存文件
    func userContentController(_ c: WKUserContentController, didReceive m: WKScriptMessage) {
        guard let b = m.body as? [String: Any], let op = b["op"] as? String else { return }
        if op == "open" {
            let p = NSOpenPanel()
            p.allowedFileTypes = ["gp", "gpx", "gp5", "gp4", "gp3", "musicxml", "xml", "mxl", "mscz", "mscx"]
            if p.runModal() == .OK, let u = p.url { send(u) }
        } else if op == "share", let s = b["data"] as? String, let d = Data(base64Encoded: s) {
            let name: String = b["name"] as? String ?? "score"
            let tmp: URL = FileManager.default.temporaryDirectory.appendingPathComponent(name)
            try? d.write(to: tmp)
            let picker = NSSharingServicePicker(items: [tmp])
            let anchor = NSRect(x: web.bounds.midX, y: web.bounds.maxY - 40, width: 1, height: 1)
            picker.show(relativeTo: anchor, of: web, preferredEdge: .minY)
        } else if op == "rec" {
            let cb: Int = b["cb"] as? Int ?? 0
            Recorder.shared.handle(b["cmd"] as? String ?? "", b) { [weak self] out in
                self?.web.evaluateJavaScript("libResult(\(cb),\(Library.json(out)))")
            }
        } else if op == "lib" {
            let cb: Int = b["cb"] as? Int ?? 0
            let out: Any = Library.run(b["cmd"] as? String ?? "", b)
            web.evaluateJavaScript("libResult(\(cb),\(Library.json(out)))")
        } else if op == "save" {
            let p = NSSavePanel()
            p.nameFieldStringValue = b["name"] as? String ?? "score.gp"
            if p.runModal() == .OK, let u = p.url, let s = b["data"] as? String, let d = Data(base64Encoded: s) {
                try? d.write(to: u)
            }
        }
    }

    func webView(_ w: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String, defaultText: String?,
                 initiatedByFrame f: WKFrameInfo, completionHandler done: @escaping (String?) -> Void) {
        let a = NSAlert(); a.messageText = prompt
        a.addButton(withTitle: "好"); a.addButton(withTitle: "取消")
        let t = NSTextField(frame: NSRect(x: 0, y: 0, width: 260, height: 24))
        t.stringValue = defaultText ?? ""; a.accessoryView = t
        let ok: Bool = a.runModal() == .alertFirstButtonReturn
        done(ok ? t.stringValue : nil)
    }
    func webView(_ w: WKWebView, runJavaScriptConfirmPanelWithMessage msg: String,
                 initiatedByFrame f: WKFrameInfo, completionHandler done: @escaping (Bool) -> Void) {
        let a = NSAlert(); a.messageText = msg
        a.addButton(withTitle: "好"); a.addButton(withTitle: "取消")
        done(a.runModal() == .alertFirstButtonReturn)
    }

    // 让 JS 的 alert() 可用
    func webView(_ w: WKWebView, runJavaScriptAlertPanelWithMessage msg: String,
                 initiatedByFrame f: WKFrameInfo, completionHandler done: @escaping () -> Void) {
        let a = NSAlert(); a.messageText = msg; a.runModal(); done()
    }
}

let app = NSApplication.shared
let delegate = AppDelegate()
app.delegate = delegate
app.setActivationPolicy(.regular)
app.run()
